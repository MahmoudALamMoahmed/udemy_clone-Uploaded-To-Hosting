export function removeFromCart(payload) {
    return {
        type: "REMOVE_FROM_CART",
        payload
    }
}