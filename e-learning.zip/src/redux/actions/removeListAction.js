export default function RemoveList(payload) {
    return {
        type: "REMOVE_LIST",
        payload
    }
}