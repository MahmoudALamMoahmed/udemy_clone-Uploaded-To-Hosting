export function addToWishlist(payload) {
    return {
        type: "ADD_TO_WISHLIST",
        payload
    }
}