export function unjoin(payload) {
    return {
        type: "UNJOIN_COURSE",
        payload
    }
}