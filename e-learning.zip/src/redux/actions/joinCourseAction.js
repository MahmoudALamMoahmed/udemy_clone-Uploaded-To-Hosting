export function joinCourse(payload) {
    return {
        type: "JOIN_COURSE",
        payload
    }
}