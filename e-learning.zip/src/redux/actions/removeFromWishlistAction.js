export function removeFromWishlist(payload) {
    return {
        type: "REMOVE_FROM_WISHLIST",
        payload
    }

}