import { Fragment } from "react";
import Courses from "../../components/courses";

export function HomePage() {

    return (
        <Fragment>
            <h2>Welocme to Home</h2>
            <Courses />
        </Fragment>
    )
}